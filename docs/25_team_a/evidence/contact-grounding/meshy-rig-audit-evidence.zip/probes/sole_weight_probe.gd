extends SceneTree
const Person=preload("res://scripts/visuals/village_person.gd")
const SkinFixture=preload("res://tests/motion_skin_measurement.gd")
func _initialize() -> void:
 _run.call_deferred()
func _run() -> void:
 var actor:=Person.new()
 root.add_child(actor)
 actor.set_process(false)
 actor.position=Vector3(0,.9,0)
 actor.configure_resident("germania",32,"spearman")
 actor.configure_meshy("unit_germanic_axe_fighter")
 actor._reload(3)
 actor._check_lod=100000.0
 await process_frame
 actor.reset_motion()
 actor.drive(1.45)
 actor._play("march",0.0,0.0)
 var skin:=SkinFixture.new()
 skin.bind(actor.body)
 var seconds:=actor.locomotion_stride("march")/1.45
 var frames:=int(ceil(seconds*60))
 var elapsed:=0.0
 var anchors:={}
 var starts:={}
 var bone_anchors:={}
 var worst:={"distance":0.0}
 var contacts:={"L":0,"R":0}
 for frame in frames+1:
  var phase:=float(frame)/frames
  var target:=phase*seconds
  var delta:=target-elapsed
  actor.position.z-=1.45*delta
  actor._process(delta)
  actor._motion.skeleton.force_update_all_bone_transforms()
  var observed:=skin.sample()
  var next:={}
  for key: int in observed.contact_points:
   var side:="R" if key%2==1 else "L"
   if not actor.world_foot_supported(side):continue
   contacts[side]+=1
   var point: Vector3=observed.contact_points[key]
   var anchor: Vector3=anchors.get(key,point)
   var rig: Skeleton3D=actor._motion.skeleton
   var bone:=rig.global_transform*rig.get_bone_global_pose(rig.find_bone("Foot_"+side))
   if not anchors.has(key):
    starts[key]=frame
    bone_anchors[key]=bone
   var distance:=Vector2(point.x-anchor.x,point.z-anchor.z).length()
   if distance>float(worst.distance):
    var surface: Dictionary=skin.surfaces[key>>32]
    var vertex: int=(key & 0xffffffff)>>1
    var bindings:={}
    for slot in surface.influences:
     var offset: int=vertex*surface.influences+slot
     if surface.weights[offset]>0:bindings[rig.get_bone_name(surface.bones[surface.joints[offset]])]=surface.weights[offset]
    worst={"distance":distance,"side":side,"frame":frame,"phase":phase,"start_frame":starts[key],"mesh":str(surface.mesh.name),"surface":surface.surface,"vertex":vertex,"rest_point":str(surface.vertices[vertex]),"normalized_rest_height":float(surface.vertices[vertex].y)/1.78,"bindings":bindings,"point":str(point),"anchor":str(anchor),"foot_origin_displacement":bone.origin.distance_to(bone_anchors[key].origin)}
   next[key]=anchor
  anchors=next
  elapsed=target
 print("SOLE_WEIGHT_PROBE ",JSON.stringify({"worst":worst,"contacts":contacts}))
 var output:=FileAccess.open("/tmp/imperathen-rig-audit-20261125/sole-weight-probe.json",FileAccess.WRITE)
 output.store_string(JSON.stringify({"worst":worst,"contacts":contacts},"  "))
 output.close()
 actor.free()
 quit()
