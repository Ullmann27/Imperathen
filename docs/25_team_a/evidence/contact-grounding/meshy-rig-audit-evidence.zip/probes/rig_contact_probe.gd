extends SceneTree
const Person=preload("res://scripts/visuals/village_person.gd")
const SkinFixture=preload("res://tests/motion_skin_measurement.gd")

class SourcePerson extends Person:
	var exact_source := ""
	func _path(_level: int) -> String: return exact_source

func _initialize() -> void:
	_run.call_deferred()

func sole_heights(skin: RefCounted) -> Dictionary:
	var result := {"L":INF,"R":INF}
	for surface: Dictionary in skin.surfaces:
		for vertex in surface.feet.size():
			var side := int(surface.feet[vertex])
			if side == 0: continue
			var point: Vector3 = surface.rig.global_transform * surface.last_posed[vertex]
			var key := "L" if side == 1 else "R"
			result[key] = minf(result[key],point.y)
	return result

func _run() -> void:
	for identity: String in ["archer", "civilian_man", "unit_germanic_axe_fighter", "unit_roman_signifer"]:
		var actor:=SourcePerson.new()
		actor.exact_source = "res://assets/characters/frontier_%s_3.glb" % identity if not identity.begins_with("unit_") else "res://assets/meshy/characters/%s_3.glb" % identity
		root.add_child(actor)
		actor.set_process(false)
		actor.position=Vector3(0,.9,0)
		actor.configure_resident("italia",32,identity if not identity.begins_with("unit_") else "legionary")
		if identity.begins_with("unit_"): actor.configure_meshy(identity)
		actor._check_lod=100000.0
		await process_frame
		var skin:=SkinFixture.new()
		skin.bind(actor.body)
		print("BIND ",identity," errors=",skin.errors," scale=",actor.body.scale," feet=",skin.foot_vertices)
		for action: String in ["idle","march","run"]:
			actor.position=Vector3(0,.9,0)
			actor.reset_motion()
			var speed:=1.45 if action=="march" else (3.6 if action=="run" else 0.0)
			actor.drive(speed)
			actor._play(action,0.0,0.0)
			var seconds: float=actor.animator.get_animation(action).length if speed==0.0 else actor.locomotion_stride(action)/speed
			var frames:=int(ceil(seconds*60))
			var minima:={"L":INF,"R":INF}
			var maximum:={"L":-INF,"R":-INF}
			for frame in frames+1:
				var delta:=0.0 if frame==0 else seconds/frames
				actor.position.z-=speed*delta
				actor._process(delta)
				actor._motion.skeleton.force_update_all_bone_transforms()
				var observed:=skin.sample()
				var heights:=sole_heights(skin)
				for side: String in ["L","R"]:
					if actor.world_foot_supported(side):
						minima[side]=minf(minima[side],heights[side])
						maximum[side]=maxf(maximum[side],heights[side])
				if frame in [0,1,frames/2,frames]:
					print("FRAME ",JSON.stringify({"identity":identity,"action":action,"frame":frame,"phase":actor.phase,"sole":heights,"supported":[actor.world_foot_supported("L"),actor.world_foot_supported("R")],"foot_L":str(actor._motion.skeleton.global_transform*actor._motion.skeleton.get_bone_global_pose(actor._motion.skeleton.find_bone("Foot_L"))),"foot_R":str(actor._motion.skeleton.global_transform*actor._motion.skeleton.get_bone_global_pose(actor._motion.skeleton.find_bone("Foot_R")))}))
			print("SUMMARY ",JSON.stringify({"identity":identity,"action":action,"minimum_supported_sole_m":minima,"maximum_supported_sole_m":maximum}))
		actor.free()
	quit()
