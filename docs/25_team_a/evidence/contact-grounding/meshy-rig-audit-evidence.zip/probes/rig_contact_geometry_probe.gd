extends SceneTree
const Person=preload("res://scripts/visuals/village_person.gd")
const SkinFixture=preload("res://tests/motion_skin_measurement.gd")
const OUTPUT="/tmp/imperathen-rig-audit-20261125/geometry"
var caption: Label

class SourcePerson extends Person:
	var exact_source := ""
	func _path(_level: int) -> String: return exact_source

func _initialize() -> void:
	_run.call_deferred()

func _run() -> void:
	DirAccess.make_dir_recursive_absolute(OUTPUT)
	if DisplayServer.get_name()!="headless": _studio()
	for identity: String in ["archer","unit_roman_signifer"]:
		for version: String in [OS.get_environment("RIG_CAPTURE_VERSION")]:
			var actor:=SourcePerson.new()
			var filename:="frontier_archer_3.glb" if identity=="archer" else identity+"_3.glb"
			actor.exact_source=("res://assets/characters/" if identity=="archer" else "res://assets/meshy/characters/")+filename
			root.add_child(actor)
			actor.set_process(false)
			actor.position=Vector3(0,.9,0)
			actor.configure_resident("italia",32,"archer" if identity=="archer" else "legionary")
			if identity!="archer": actor.configure_meshy(identity)
			actor._check_lod=100000.0
			await process_frame
			actor.reset_motion()
			var action:="idle" if identity=="archer" else "march"
			actor.drive(0.0 if action=="idle" else 1.45)
			actor._play(action,0.0,0.0)
			actor._process(0.0)
			actor._motion.skeleton.force_update_all_bone_transforms()
			var skin:=SkinFixture.new()
			skin.bind(actor.body)
			var sampled:=skin.sample()
			var surfaces:=[]
			var heights:={"L":INF,"R":INF}
			for surface: Dictionary in skin.surfaces:
				var positions:=[]
				for vertex in surface.last_posed.size():
					var p: Vector3=surface.rig.global_transform*surface.last_posed[vertex]
					positions.append([p.x,p.y,p.z])
					if surface.feet[vertex]!=0:
						var side:="L" if surface.feet[vertex]==1 else "R"
						heights[side]=minf(heights[side],p.y)
				surfaces.append({"name":str(surface.mesh.name),"vertices":positions,"indices":Array(surface.indices),"feet":Array(surface.feet)})
			var equipment:=[]
			for node: Node in actor.body.find_children("*","BoneAttachment3D",true,false):
				if node.get_meta("meshy_equipment",false): equipment.append({"asset_id":node.get_meta("asset_id"),"model_path":node.get_meta("model_path")})
			var record:={"identity":identity,"version":version,"action":action,"source":actor.exact_source,"sole_heights_m":heights,"finite":sampled.finite,"surfaces":surfaces,"scope":"Actual Godot production VillagePerson pose and CPU-evaluated imported skin; geometric visualization only","runtime":{"role":actor.role,"identity":actor.identity,"appearance":actor.appearance_id,"variation":actor.appearance_variation,"age":actor.age,"home":actor.home,"detail":actor.detail,"phase":actor.phase,"clip":actor.clip,"speed":actor.speed,"active_model_path":actor.active_model_path,"meshy_asset_id":actor.meshy_asset_id,"scale":str(actor.body.scale),"equipment":equipment}}
			if DisplayServer.get_name()!="headless":
				caption.text=("Frontier archer / idle" if identity=="archer" else "Roman signifer / march, first support")+" — "+version.to_upper()+"\nActual sole height: L %.2f mm / R %.2f mm" % [heights.L*1000.0,heights.R*1000.0]
				for frame in 3: await process_frame
				await RenderingServer.frame_post_draw
				var capture:=root.get_texture().get_image()
				capture.save_png(OUTPUT.path_join(identity+"-"+version+".png"))
				record["renderer"]=RenderingServer.get_current_rendering_method()
				record["adapter"]=RenderingServer.get_video_adapter_name()
				record["scope"]="Actual Godot production VillagePerson pose and viewport; desktop software renderer, not Android performance evidence"
			var file:=FileAccess.open(OUTPUT.path_join(identity+"-"+version+".json"),FileAccess.WRITE)
			file.store_string(JSON.stringify(record))
			file.close()
			print("GEOMETRY ",identity," ",version," ",heights)
			actor.free()
	quit()

func _studio() -> void:
	var environment:=WorldEnvironment.new()
	var settings:=Environment.new()
	settings.background_mode=Environment.BG_COLOR
	settings.background_color=Color(.11,.13,.17)
	settings.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR
	settings.ambient_light_color=Color(.8,.85,.95)
	settings.ambient_light_energy=.65
	environment.environment=settings
	root.add_child(environment)
	var light:=DirectionalLight3D.new()
	light.rotation_degrees=Vector3(-42,-35,0)
	light.light_energy=1.1
	light.shadow_enabled=true
	root.add_child(light)
	var material:=StandardMaterial3D.new()
	material.albedo_color=Color(.34,.37,.40)
	material.roughness=1.0
	var floor_mesh:=PlaneMesh.new()
	floor_mesh.size=Vector2(5,5)
	var floor_instance:=MeshInstance3D.new()
	floor_instance.mesh=floor_mesh
	floor_instance.material_override=material
	root.add_child(floor_instance)
	var grid_material:=StandardMaterial3D.new()
	grid_material.albedo_color=Color(.45,.49,.53)
	grid_material.roughness=1.0
	for axis in 2:
		for line in 21:
			var grid:=MeshInstance3D.new()
			var box:=BoxMesh.new()
			box.size=Vector3(2,.0005,.0015) if axis==0 else Vector3(.0015,.0005,2)
			grid.mesh=box
			grid.position=Vector3(0,.00025,(line-10)*.1) if axis==0 else Vector3((line-10)*.1,.00025,0)
			grid.material_override=grid_material
			root.add_child(grid)
	var camera:=Camera3D.new()
	camera.projection=Camera3D.PROJECTION_ORTHOGONAL
	camera.size=1.12
	camera.near=.01
	camera.far=20
	root.add_child(camera)
	camera.position=Vector3(.55,.25,1.25)
	camera.look_at(Vector3(0,.12,-.06))
	camera.current=true
	var layer:=CanvasLayer.new()
	root.add_child(layer)
	var backdrop:=ColorRect.new()
	backdrop.position=Vector2(24,18)
	backdrop.size=Vector2(950,92)
	backdrop.color=Color(.04,.05,.07,.88)
	layer.add_child(backdrop)
	caption=Label.new()
	caption.position=Vector2(32,24)
	caption.add_theme_font_size_override("font_size",28)
	caption.add_theme_color_override("font_color",Color.WHITE)
	layer.add_child(caption)
	var scope:=Label.new()
	scope.position=Vector2(32,680)
	scope.text="Godot 4.7.2 · actual imported LOD3 skin · 10 cm ground grid · Compatibility / software · no Android FPS claim"
	scope.add_theme_font_size_override("font_size",18)
	layer.add_child(scope)
