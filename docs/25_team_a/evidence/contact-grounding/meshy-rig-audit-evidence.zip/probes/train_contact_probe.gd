extends SceneTree
const Person=preload("res://scripts/visuals/village_person.gd")
const SkinFixture=preload("res://tests/motion_skin_measurement.gd")
func _initialize() -> void:
 _run.call_deferred()
func _run() -> void:
 var actor:=Person.new()
 root.add_child(actor)
 actor.set_process(false)
 actor.position=Vector3(0,.9,0)
 actor.configure_resident("italia",32,"legionary")
 actor.configure_meshy("unit_roman_signifer")
 actor._reload(3)
 actor._check_lod=100000.0
 await process_frame
 actor.reset_motion()
 actor.drive(0.0)
 actor.cue("train")
 actor._motion.capture_transition(0.0)
 actor._play("train",0.0,0.0)
 var skin:=SkinFixture.new()
 skin.bind(actor.body)
 var seconds:=actor.animator.get_animation("train").length
 var frames:=int(ceil(seconds*60))
 var elapsed:=0.0
 var anchors:={}
 var starts:={}
 var bone_anchors:={}
 var worst:={"distance":0.0}
 var contacts:={"L":0,"R":0}
 var supported_anchors:={}
 var supported_max:=0.0
 var starts_supported:={}
 var all_frames:=[]
 for frame in frames+1:
  var phase:=float(frame)/frames
  var target:=phase*seconds
  var delta:=target-elapsed
  actor._process(delta)
  actor._motion.skeleton.force_update_all_bone_transforms()
  var observed:=skin.sample()
  var next:={}
  var next_supported:={}
  var frame_contacts:=[]
  for key: int in observed.contact_points:
   var side:="R" if key%2==1 else "L"
   var supported:=actor.world_foot_supported(side)
   contacts[side]+=1
   var point: Vector3=observed.contact_points[key]
   var anchor: Vector3=anchors.get(key,point)
   if supported:
    var planted_anchor: Vector3=supported_anchors.get(key,point)
    supported_max=maxf(supported_max,Vector2(point.x-planted_anchor.x,point.z-planted_anchor.z).length())
    next_supported[key]=planted_anchor
   var rig: Skeleton3D=actor._motion.skeleton
   var bone:=rig.global_transform*rig.get_bone_global_pose(rig.find_bone("Foot_"+side))
   if not anchors.has(key):
    starts[key]=frame
    starts_supported[key]=supported
    bone_anchors[key]=bone
   var distance:=Vector2(point.x-anchor.x,point.z-anchor.z).length()
   if distance>float(worst.distance):
    var surface: Dictionary=skin.surfaces[key>>32]
    var vertex: int=(key & 0xffffffff)>>1
    var bindings:={}
    for slot in surface.influences:
     var offset: int=vertex*surface.influences+slot
     if surface.weights[offset]>0:bindings[rig.get_bone_name(surface.bones[surface.joints[offset]])]=surface.weights[offset]
    worst={"distance":distance,"side":side,"frame":frame,"phase":phase,"start_frame":starts[key],"mesh":str(surface.mesh.name),"surface":surface.surface,"vertex":vertex,"rest_point":str(surface.vertices[vertex]),"normalized_rest_height":float(surface.vertices[vertex].y)/1.78,"bindings":bindings,"point":str(point),"anchor":str(anchor),"foot_origin_displacement":bone.origin.distance_to(bone_anchors[key].origin),"supported":supported,"start_supported":starts_supported[key],"foot_origin":str(bone.origin),"start_foot_origin":str(bone_anchors[key].origin),"foot_rotation_deg":rad_to_deg(bone.basis.get_rotation_quaternion().angle_to(bone_anchors[key].basis.get_rotation_quaternion()))}
   next[key]=anchor
   frame_contacts.append({"key":key,"point":[point.x,point.y,point.z],"supported":supported,"foot_origin":[bone.origin.x,bone.origin.y,bone.origin.z]})
  anchors=next
  supported_anchors=next_supported
  all_frames.append({"frame":frame,"phase":phase,"contacts":frame_contacts})
  elapsed=target
 print("TRAIN_CONTACT_PROBE ",JSON.stringify({"worst":worst,"contacts":contacts,"supported_max_slip_m":supported_max}))
 var output:=FileAccess.open("/tmp/imperathen-rig-audit-20261125/train-contact-probe.json",FileAccess.WRITE)
 output.store_string(JSON.stringify({"worst":worst,"contacts":contacts,"supported_max_slip_m":supported_max,"frames":all_frames},"  "))
 output.close()
 actor.free()
 quit()
