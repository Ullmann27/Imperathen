import os,sys,subprocess,pathlib,tempfile,json
root=pathlib.Path("/tmp/imperathen-rig-audit-20261125/repo").resolve();sys.path.insert(0,str(root/"tools"));from motion_quality_gate import source_fingerprint
out=pathlib.Path("/tmp/imperathen-rig-audit-20261125/meshy-final");out.mkdir(exist_ok=True)
fingerprint=source_fingerprint(root);(out/"source-fingerprint.txt").write_text(fingerprint+"\n");print("source_fingerprint",fingerprint,flush=True)
for p in sorted((root/"prototype/assets/meshy/characters").glob("*.glb")):
 subject=p.relative_to(root/"prototype").as_posix();stem=p.stem;env=os.environ.copy();env.update(IMPERATHEN_ISOLATED_TEST="1",IMPERATHEN_MOTION_CONTRACT=str(root/"quality/motion_contract.json"),IMPERATHEN_MOTION_REPORT=str(out/(stem+".json")),IMPERATHEN_MOTION_SOURCE=fingerprint,IMPERATHEN_MOTION_ONLY_SUBJECT=subject)
 with tempfile.TemporaryDirectory(prefix="rig-gait-final-") as tmp:
  for kind in ("DATA","CONFIG","CACHE"):
   d=pathlib.Path(tmp)/kind.lower();d.mkdir();env["XDG_"+kind+"_HOME"]=str(d)
  with (out/(stem+".log")).open("w") as f:
   r=subprocess.run(["godot","--headless","--path",str(root/"prototype"),"--fixed-fps","60","--script","res://tests/motion_quality_measurement.gd"],env=env,cwd=root,stdout=f,stderr=subprocess.STDOUT,timeout=180)
  if r.returncode!=0: raise RuntimeError(stem+" failed: "+str(r.returncode))
  measured=json.loads((out/(stem+".json")).read_text());assert measured["fatal"]==[] and measured["complete"] is False
  print(stem,"ok",flush=True)
assert source_fingerprint(root)==fingerprint
