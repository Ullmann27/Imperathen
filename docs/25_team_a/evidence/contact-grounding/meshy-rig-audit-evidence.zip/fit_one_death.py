import importlib.util,bpy,json
from pathlib import Path
root=Path("/tmp/imperathen-rig-audit-20261125/repo")
s=importlib.util.spec_from_file_location("frontier",root/"tools/characters/build_frontier_people.py");f=importlib.util.module_from_spec(s);s.loader.exec_module(f)
f.LOD=((3,.025,256),)
bpy.ops.wm.open_mainfile(filepath=str(root/"art/frontier_people/archer.blend"))
arm=bpy.data.objects["FrontierRig"]
death=next(track.strips[0].action for track in arm.animation_data.nla_tracks if track.name=="death")
print("DEATH_ACTION",death.name,flush=True)
death.name="death"
print("DEATH_GROUND",f.hero.fit_death_ground_contact(arm),flush=True)
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(root/"art/frontier_people/archer.blend"),compress=True)
f.export("archer")
print("DEATH_KEYS",f.hero.preserve_grounded_death_keys(root/"prototype/assets/characters/frontier_archer_3.glb",bpy.data.objects["FrontierRig"]),flush=True)
