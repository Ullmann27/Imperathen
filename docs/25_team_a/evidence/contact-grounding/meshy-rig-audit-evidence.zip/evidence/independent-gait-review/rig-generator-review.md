# Unabhängiges Review der Meshy-/Frontier-Generatoren

Basis: `261639105dcaa72f8dd92e73f4db1d9ab7d90a23`.
Arbeitskopie: `/dev/shm/imperathen-rig-audit-20261125`.
Review-Stand: vorhandener Gait-Kandidat vor weiteren Vertex-/Weight-Änderungen.

## Empfehlung und Umfang

Die **Meshy-IK-Korrektur ist für beide vorhandenen Profile mathematisch
bestätigt**. Die acht neu erzeugten Derivate behalten die originalen
Mesh-Accessors und alle neun Nicht-Gait-Animationen. Die neue Python-Regression
ist zur gemeinsamen Integration mit dieser Generatoränderung bereit.

Das ist **keine Freigabe der vollständigen Bewegungsqualität**: die aktuelle
reale Axe-LOD3-Messung zeigt beim Marsch 17.269 mm Slip bei nun vollständiger
Abdeckung beider Füße. Die Vertex-/Weight-Ursache wird noch untersucht.
Frontier bleibt ein Kandidat; sein isolierter Death-Reuse verbessert die
Penetration, lässt aber weitere Grenzüberschreitungen bestehen.

Dieses Review startete keinen Blender-/Godot-Prozess und keine komplette Suite.
Es schrieb im Repository ausschließlich den von Root freigegebenen Pfad
`tests/meshy_gait_reach_test.py`. Generatoren und Assets blieben bei rig_audit.

## 1. Meshy: Geometrie und gemeinsame Beckenhöhe

`soldier.animate()` konjugiert armature-globale X-Rotationen in die
Bone-Ruhebasis. Für diese sagittalen Rotationen sind deshalb die YZ-Projektionen
der Oberschenkel-/Unterschenkelvektoren die richtigen Längen im planaren
Zweigliedsolver. Die X-Komponenten bleiben konstant. Die unabhängige
Vorwärtskinematik benutzt weiterhin die vollständigen tatsächlichen
3D-Restvektoren; die reale Segmentlänge wird nicht verkürzt.

Die erste Schleife bildet aus beiden Beinen eine gemeinsame obere Grenze für
den Pelvis-Lift. Erst anschließend werden beide Beine mit derselben endgültigen
Beckenhöhe gelöst. Dadurch kann das zweite Bein nicht nachträglich die
Beckenposition verändern, auf der bereits die erste Lösung beruhte.

Numerische Gegenprobe: tatsächliche alte/neue Produktionsfunktionen und
Skeleton-Koordinaten, je 10.001 Phasen pro Profil und Gang:

| Profil | Gang | Größte alte Zielabweichung | Größte neue Zielabweichung | Zusätzliche Absenkung |
| --- | --- | ---: | ---: | ---: |
| Signifer | march | 53.410 mm | < 2e-12 mm | 64.008 mm |
| Signifer | run | 54.169 mm | < 2e-12 mm | 65.441 mm |
| Axe fighter | march | 53.662 mm | < 3e-12 mm | 64.362 mm |
| Axe fighter | run | 54.443 mm | < 3e-12 mm | 65.834 mm |

Das sind idealisierte numerische FK-Ergebnisse, keine Genauigkeitsbehauptung für
Godot-Meshvertices. Beide Beine halten mindestens 3 mm äußere Reichweitenreserve.
Die kleinste Entfernung zur inneren Zweiglied-Reichweitengrenze ist über
664 mm; der kleinste geprüfte Wurzelradikand über 0.505 m². Keine Nullnenner,
nichtendlichen Werte oder negativen Zielhöhen wurden für die aktuellen Profile
gefunden.

Die zusätzliche Absenkung ist mit bis rund 6.6 cm eine sichtbare
Haltungsänderung. Die geplante echte Godot-Aufnahme sollte deshalb auch Hüfte,
Kniebeugung und Wechsel zwischen march/run zeigen.

### Reichweiten-/Nullfälle

Die geprüften festen Profile sind ausreichend weit von degenerierten Längen
und innerer Reichweitengrenze entfernt. Die Funktion ist weiterhin kein
beliebiger generischer IK-Solver: Bei einem zukünftig rein lateralen Glied
wären YZ-Länge beziehungsweise Nenner null; ein horizontal bereits außerhalb
der Gesamtreichweite liegendes Ziel wird durch `sqrt(max(0,...))` allein nicht
erreichbar. Für solche neuen Profile ist keine Freigabe erteilt. Der Test
prüft ausdrücklich die beiden vorhandenen Profile und ihre realen
nichtverschwindenden lateralen Offsets.

## 2. Aussagekräftige Python-Regression

Datei: `tests/meshy_gait_reach_test.py`.

Der Test extrahiert und führt die unveränderten tatsächlichen
`PROFILES`, `CLIPS`, `clamp()`, `skeleton()` und `animate()`-Definitionen
aus dem Generator aus. Kleine Bone-Datensätze ersetzen nur die Blender-
Armaturerstellung; die IK-Formeln werden nicht kopiert. Unabhängige
Vorwärtskinematik prüft:

- beide tatsächlichen Profile und beide Gänge über mehr als 1.000 Phasen,
  einschließlich Stützgrenzen und 25-fps-Authoring-Keys;
- reale 3D-Segmentlängen und endliche Posewerte;
- unveränderte Standhöhe, seitliche Lage und vorgeschriebene Standtrajektorie
  beider Fußgelenke mit derselben Beckenhöhe;
- Sohlenorientierung, ausreichende Schwunghöhe und keine abgesunkene Schwungpose;
- identische Loop-Endpunkte beider Beine und des gemeinsamen Beckens.

Befehl:
```sh
python3 -B -m unittest discover -s tests -p 'meshy_gait_reach_test.py' -v
```

Ergebnis: **5/5 Testmethoden bestanden**, etwa 0.2 Sekunden, Standardbibliothek.
Kein `bpy`, `bmesh`, `numpy` oder `mathutils` importiert.
Mit einem separaten, unveränderten Originalquellen-Snapshot entstehen vier
echte Stützpunktfehler für die vier Profil-/Gangkombinationen, etwa
42–44 mm Abweichung. Keine Harness-Fehler. Die Arbeitskopie musste für die
negative Gegenprobe nicht zurückgesetzt werden.

Der Test ist ein Generator-Regressionstest. Er ersetzt weder Export-/Skin-
Prüfungen noch die Runtime- und visuelle Abnahme. Die bestehenden selektiven
Python-CI-Kommandos müssen den neuen Dateinamen ausdrücklich aufnehmen;
Workflow-/Manifeständerungen waren nicht Teil meiner Schreibfreigabe.

## 3. Andere Clips und reale aktuelle Messung

Der gespeicherte all8-Accessor-Vergleich bestätigt bei allen acht Derivaten:
- identische Positionen, Normalen, UVs, Skin-Joints/-Weights und Indices;
- identische neun Nicht-Gait-Animationen einschließlich death;
- Änderungen der Animationskanäle ausschließlich in march und run.

Mesh-Ressourcennamenssuffixe können sich durch den Blender-Export ändern.
Der Vergleich behauptet keine Bytegleichheit der gesamten GLB oder ihrer
Texturcontainer. Rig_audit hat diesen Vergleich mit dem hier bereitgestellten
Vergleichsskript ausgeführt; ich habe alle acht Ergebniszeilen gelesen.

Beim Signifer LOD3 verbessert sich die tatsächliche Support-Abdeckung:
march von L44/R0 auf L544/R236, run von L16/R0 auf L221/R108.
Der nun gemessene Slip beträgt 6.023 mm beziehungsweise 4.809 mm.
Alle anderen tatsächlichen Runtime-Aktionen in diesem Datensatz sind
metrisch unverändert.

**Offener konkreter Gegenbefund: Axe fighter LOD3, march.**
Der neue reale Slip beträgt 17.269151 mm und liegt über dem unveränderten
15-mm-Limit. Die Abdeckung wächst von L64/R0 auf L604/R672, der vorherige
Missing-R-Sample-Fehler entfällt. Der alte Slipwert 2.809854 mm beruhte somit auf
unvollständiger Abdeckung und darf nicht als vollständig vergleichbarer
Qualitätserfolg ausgegeben werden. Die aktuelle Segment- und
Schleifenabweichung verbessert sich; die tatsächliche Kontaktqualität bleibt
dennoch offen. Eine Decimation-/Weight-Ursache ist bis zum konkreten
Vertexbefund eine Hypothese.

## 4. Frontier-Fußabbildung

Die vorgeschlagene affine Abbildung passt den Fußgrundriss in XY und die
Knöchelhöhe separat an. Algebraisch gilt für den Z-Anteil:
`dst_z + (dst_z/src_z)*(z-src_z) = (dst_z/src_z)*z`.
Da die zusätzliche Drehung nur um Z erfolgt, bleibt Z=0 erhalten und der
Quellknöchel wird weiterhin auf den Zielknöchel abgebildet.

Unabhängige Rekonstruktion aus den gebündelten Anatomie-Punkten und den
vorhandenen Target-Dateien bestätigt für beide Seiten:
- Quell-Foot-XY-Länge: 0.136055707 m;
- Quell-Knöchel-Z: 0.060619003 m;
- Zielwerte: 0.16 m beziehungsweise 0.12 m;
- positive Faktoren: 1.175988895 horizontal, 1.979577264 vertikal.

Es gibt für diese tatsächlichen Rigs keinen Nullnenner. Die Garantie für die
Grundebene gilt für den Foot-Anteil der Transformation; gemischt an Shin/Foot
gebundene Meshvertices müssen weiterhin anhand des wirklichen Meshes geprüft
werden.

Der erste affine Archer-LOD3-Kandidat verbessert die Kontaktabdeckung, steigert
aber Todespenetration 135.121→160.486 mm und Todesslip
803.433→881.238 mm. Retreat zeigt nach erstmals vorhandener Abdeckung
51.523 mm Slip; die vorherige Nullmessung hatte keine Kontakte.

Der anschließende isolierte Reuse von `fit_death_ground_contact()` plus
`preserve_grounded_death_keys()` erzeugt 73 Keys und verbessert death auf
4.760 mm Penetration sowie 42.848 mm Slip. Nicht-death-Clipmetriken bleiben in
diesem Vergleich gleich. Damit ist die Penetrationsregression deutlich
verbessert, aber der Slip weiterhin über dem Limit.

Zusätzlich ist bei der Wiederverwendung die konkrete NLA-Action des
FrontierRig zu verwenden. Die Hero-Helfer greifen global auf Action `death`
zu, während die neu angelegte Company-Action nach dem Hero-Import
`death.001` heißen kann. Rig_audit hat den tatsächlichen Track im
erfolgreichen Einzelversuch aufgelöst; eine allgemeine Generatorintegration
wurde hier nicht geprüft.

Frontier bleibt außerdem wegen der von rig_audit festgestellten Abweichung
zwischen aktuellen Hero-/Equipment-Quellen und älterem Frontier-Buildbericht
außerhalb einer pauschalen Regeneration. Die isolierte Fußformel rechtfertigt
keine unbeprüfte Veränderung anderer Assetbestandteile.

## Gesicherte Nachweise

Dieser Ordner enthält den Testpatch, Testlogs, vollständige alte/neue
Meshy-Generatorquellen, aktuelle Profil-/Knochenwerte, FK-Ergebnisse,
Foot-Affine-Quelldaten, relevante Rohmessungen und den all8-Accessor-Vergleich.
`SHA256SUMS.json` bindet die Kopien an ihren tatsächlichen Inhalt.
