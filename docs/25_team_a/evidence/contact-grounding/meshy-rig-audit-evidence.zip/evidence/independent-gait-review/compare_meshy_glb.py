"""Compare actual Meshy GLB mesh accessors and animation channels without Blender."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--ref", default="261639105dcaa72f8dd92e73f4db1d9ab7d90a23")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("paths", nargs="*")
    args = parser.parse_args()
    root = args.repo.resolve()
    spec = importlib.util.spec_from_file_location("review_glb_reader", root / "tools/art/validate_visual_assets.py")
    reader = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(reader)

    def decode(raw):
        document, binary, warnings = reader.read_glb(raw)
        inspection = reader.Inspection(document, binary, warnings)
        inspection.inspect_buffers()
        return document, inspection

    def meshes(document, inspection):
        return [[{"mode": primitive.get("mode", 4),
                  "indices": inspection.decode(primitive["indices"]),
                  "attributes": {name: inspection.decode(index)
                                 for name, index in primitive["attributes"].items()}}
                 for primitive in mesh["primitives"]] for mesh in document["meshes"]]

    def animations(document, inspection):
        result = {}
        for animation in document["animations"]:
            channels = {}
            for channel in animation["channels"]:
                target = channel["target"]
                key = document["nodes"][target["node"]]["name"] + "/" + target["path"]
                if key in channels:
                    raise ValueError("Duplicate animation target: " + key)
                sampler = animation["samplers"][channel["sampler"]]
                channels[key] = (sampler.get("interpolation", "LINEAR"),
                                 inspection.decode(sampler["input"]),
                                 inspection.decode(sampler["output"]))
            if animation["name"] in result:
                raise ValueError("Duplicate animation name")
            result[animation["name"]] = channels
        return result

    paths = args.paths or [str(path.relative_to(root)) for path in sorted(
        (root / "prototype/assets/meshy/characters").glob("unit_*_[0-3].glb"))]
    rows = []
    for path in paths:
        old_raw = subprocess.check_output(["git", "show", args.ref + ":" + path], cwd=root)
        new_raw = (root / path).read_bytes()
        before, br = decode(old_raw)
        after, ar = decode(new_raw)
        old_clips, new_clips = animations(before, br), animations(after, ar)
        channels = {}
        for name in sorted(set(old_clips) | set(new_clips)):
            old, new = old_clips.get(name, {}), new_clips.get(name, {})
            channels[name] = [key for key in sorted(set(old) | set(new)) if old.get(key) != new.get(key)]
        record = {
            "path": path,
            "before_sha256": hashlib.sha256(old_raw).hexdigest(),
            "after_sha256": hashlib.sha256(new_raw).hexdigest(),
            "mesh_accessors_unchanged": meshes(before, br) == meshes(after, ar),
            "mesh_names_before": [mesh.get("name") for mesh in before["meshes"]],
            "mesh_names_after": [mesh.get("name") for mesh in after["meshes"]],
            "animation_channels_changed": channels,
            "non_gait_channels_unchanged": all(not changes for clip, changes in channels.items()
                                              if clip not in ("march", "run")),
        }
        rows.append(record)
        print(path, "mesh_equal=" + str(record["mesh_accessors_unchanged"]),
              "non_gait_equal=" + str(record["non_gait_channels_unchanged"]))
    report = {"base_commit": args.ref, "scope": "Decoded GLB accessor comparison; excludes rendering and runtime deformation",
              "assets": rows}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    main()
