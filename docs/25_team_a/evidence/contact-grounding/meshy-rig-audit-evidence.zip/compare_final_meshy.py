import importlib.util,json,hashlib,subprocess
from pathlib import Path
root=Path("/tmp/imperathen-rig-audit-20261125/repo");prior=Path("/tmp/imperathen-rig-audit-20261125/gait-only-assets")
s=importlib.util.spec_from_file_location("reader",root/"tools/art/validate_visual_assets.py");reader=importlib.util.module_from_spec(s);s.loader.exec_module(reader)
def decode(raw):
 d,b,w=reader.read_glb(raw);r=reader.Inspection(d,b,w);r.inspect_buffers();return d,r
def mesh(d,r):return [[{"indices":r.decode(p["indices"]),"attributes":{k:r.decode(v) for k,v in p["attributes"].items()}} for p in m["primitives"]] for m in d["meshes"]]
def clips(d,r):
 result={}
 for a in d["animations"]:
  channels={}
  for c in a["channels"]:
   sampler=a["samplers"][c["sampler"]];key=d["nodes"][c["target"]["node"]]["name"]+"/"+c["target"]["path"]
   channels[key]=(sampler.get("interpolation","LINEAR"),r.decode(sampler["input"]),r.decode(sampler["output"]))
  result[a["name"]]=channels
 return result
records=[]
for p in sorted((root/"prototype/assets/meshy/characters").glob("*.glb")):
 oldraw=(prior/p.name).read_bytes();newraw=p.read_bytes();basebytes=subprocess.check_output(["git","show","261639105dcaa72f8dd92e73f4db1d9ab7d90a23:"+p.relative_to(root).as_posix()],cwd=root)
 old,or_=decode(oldraw);new,nr=decode(newraw);base,br=decode(basebytes)
 om,nm=mesh(old,or_),mesh(new,nr);assert len(om)==len(nm)
 geometry_equal=True;weight_changes=[];changed_only_rigid_feet=True;changed_attributes=set()
 # The current derivatives contain one skinned body and one skin.
 assert len(new["skins"])==len(old["skins"])==1
 oldnames=[old["nodes"][i]["name"] for i in old["skins"][0]["joints"]];newnames=[new["nodes"][i]["name"] for i in new["skins"][0]["joints"]]
 for mi,(a,b) in enumerate(zip(om,nm)):
  for si,(pa,pb) in enumerate(zip(a,b)):
   assert set(pa["attributes"])==set(pb["attributes"])
   geometry_equal &= pa["indices"]==pb["indices"]
   aa,bb=pa["attributes"],pb["attributes"]
   for key in aa:
    if aa[key]!=bb[key]:changed_attributes.add(key)
    if not key.startswith(("JOINTS_","WEIGHTS_")):geometry_equal &= aa[key]==bb[key]
   assert len(aa["POSITION"])==len(bb["POSITION"])
   for i,(oldj,oldw,newj,neww) in enumerate(zip(aa["JOINTS_0"],aa["WEIGHTS_0"],bb["JOINTS_0"],bb["WEIGHTS_0"])):
    oldbinding={oldnames[j]:w for j,w in zip(oldj,oldw) if w>0};newbinding={newnames[j]:w for j,w in zip(newj,neww) if w>0}
    if oldbinding==newbinding:continue
    rigid=(len(newbinding)==1 and next(iter(newbinding)) in ("Foot_L","Foot_R") and next(iter(newbinding.values()))==1.0)
    changed_only_rigid_feet &= rigid
    weight_changes.append({"mesh":mi,"surface":si,"vertex":i,"position":bb["POSITION"][i],"before":oldbinding,"after":newbinding})
 oc,nc,bc=clips(old,or_),clips(new,nr),clips(base,br)
 record={"path":p.relative_to(root).as_posix(),"base_sha256":hashlib.sha256(basebytes).hexdigest(),"gait_candidate_sha256":hashlib.sha256(oldraw).hexdigest(),"final_sha256":hashlib.sha256(newraw).hexdigest(),"geometry_attributes_and_indices_unchanged":geometry_equal,"changed_mesh_attributes":sorted(changed_attributes),"changed_binding_count":len(weight_changes),"every_changed_binding_is_rigid_foot":changed_only_rigid_feet,"all_animation_channels_equal_gait_candidate":oc==nc,"nine_non_gait_clips_equal_base":all(bc[k]==nc[k] for k in bc if k not in ("march","run")),"changed_weights":weight_changes}
 assert geometry_equal and changed_only_rigid_feet and oc==nc and record["nine_non_gait_clips_equal_base"],p.name
 records.append(record);print(p.name,len(weight_changes),"rigid foot assignments; unchanged geometry and animations",flush=True)
Path("/tmp/imperathen-rig-audit-20261125/meshy-final-accessor-comparison.json").write_text(json.dumps({"base_commit":"261639105dcaa72f8dd92e73f4db1d9ab7d90a23","assets":records},indent=2)+"\n")
