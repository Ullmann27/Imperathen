import importlib.util,os,tempfile,subprocess,json,hashlib
from pathlib import Path
root=Path("/tmp/imperathen-rig-audit-20261125/repo")
s=importlib.util.spec_from_file_location("capture",root/"tools/characters/capture_hero.py");m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
out=Path("/tmp/imperathen-rig-audit-20261125/geometry-final");original=Path("/tmp/imperathen-rig-audit-20261125/baseline-assets")
out.mkdir(exist_ok=True)
paths=[root/"prototype/assets/meshy/characters/unit_germanic_axe_fighter_3.glb",root/"prototype/assets/meshy/characters/unit_roman_signifer_3.glb"]
after={p:p.read_bytes() for p in paths}
manifest={"base_commit":"261639105dcaa72f8dd92e73f4db1d9ab7d90a23","changes":"final Meshy sagittal gait reach plus preservation of originally rigid Foot weights; canonical source paths swapped and imported for each comparison","captures":[]}
with tempfile.TemporaryDirectory(prefix="rig-contact-display-") as tmp:
 directory=Path(tmp);env=os.environ.copy();env["IMPERATHEN_ISOLATED_TEST"]="1"
 for kind in ("DATA","CONFIG","CACHE"):
  d=directory/kind.lower();d.mkdir();env[f"XDG_{kind}_HOME"]=str(d)
 server,log=m.start_display(directory,env)
 try:
  for version in ("before","after"):
   for p in paths: p.write_bytes((original/p.name).read_bytes() if version=="before" else after[p])
   with (out/("import-"+version+".log")).open("w") as f:
    imp=subprocess.run(["godot","--headless","--editor","--path",str(root/"prototype"),"--import"],env=env,cwd=root,stdout=f,stderr=subprocess.STDOUT,timeout=90);assert imp.returncode==0
   env["RIG_CAPTURE_VERSION"]=version
   command=["godot","--display-driver","x11","--rendering-method","gl_compatibility","--audio-driver","Dummy","--path",str(root/"prototype"),"--resolution","1600x900","--max-fps","30","--script","/tmp/imperathen-rig-audit-20261125/probes/meshy_contact_final_capture.gd"]
   with (out/("runtime-"+version+".log")).open("w") as f: result=subprocess.run(command,env=env,cwd=root,stdout=f,stderr=subprocess.STDOUT,timeout=90)
   assert result.returncode==0
   for identity in ("unit_germanic_axe_fighter","unit_roman_signifer"):
    p=out/(identity+"-"+version+".json");r=json.loads(p.read_text());source=root/"prototype"/r["source"].replace("res://","");png=p.with_suffix(".png")
    manifest["captures"].append({"file":png.name,"sha256":hashlib.sha256(png.read_bytes()).hexdigest(),"source_glb":r["source"],"source_sha256":hashlib.sha256(source.read_bytes()).hexdigest(),"sole_heights_m":r["sole_heights_m"],"renderer":r.get("renderer"),"adapter":r.get("adapter"),"runtime":r["runtime"]})
   print("CAPTURE",version,"ok",flush=True)
 finally:
  for p in paths:p.write_bytes(after[p])
  server.terminate();server.wait(timeout=5);log.close()
for identity in ("unit_germanic_axe_fighter","unit_roman_signifer"):
 rows=[r for r in manifest["captures"] if r["file"].startswith(identity+"-")];assert rows[0]["runtime"]==rows[1]["runtime"],identity+" runtime differs"
(out/"capture-manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
